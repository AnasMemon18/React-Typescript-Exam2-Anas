
import DefaultAuth from "layouts/auth/Default";
import illustration from "assets/img/auth/auth.png";
import routes from 'routes';
import React from "react";
import { useHistory } from 'react-router-dom';


import { MdOutlineRemoveRedEye } from "react-icons/md";
import { RiEyeCloseLine } from "react-icons/ri";
// Chakra imports
import {
    Box,
    Button,
    Checkbox,
    Flex,
    FormControl,
    FormLabel,
    Heading,
    HStack,
    Icon,
    Input,
    InputGroup,
    InputRightElement,
    Radio,
    RadioGroup,
    Select,
    Text,
    Textarea,
    useColorModeValue,
} from "@chakra-ui/react";
// Custom components


function Signup() {
    // const [selectedOption, setSelectedOption] = useState();

    // Chakra color mode
    const textColor = useColorModeValue("navy.700", "white");
    const textColorSecondary = "gray.400";
    const textColorDetails = useColorModeValue("navy.700", "secondaryGray.600");
    const textColorBrand = useColorModeValue("brand.500", "white");
    const brandStars = useColorModeValue("brand.500", "brand.400");

    const [show, setShow] = React.useState(false);
    const handleClick = () => setShow(!show);
    const registerHandler = () => {

    }


    // Select change function
    // const handleSelectChange = (selectedOption: any) => {
    //     setSelectedOption(selectedOption);
    // };


    //Skills list
    const skillsList = [
        { value: "Javascript", label: "Javascript" },
        { value: "Java", label: "Java" },
        { value: "C++", label: "C++" },
        { value: "Python", label: "Python" },
    ];
    return (
        <DefaultAuth illustrationBackground={illustration} image={illustration}>


            <Flex
                maxW={{ base: "100%", md: "max-content" }}
                w="100%"
                mx={{ base: "auto", lg: "0px" }}
                me="auto"
                alignItems="start"
                justifyContent="center"
                mb={{ base: "30px", md: "60px" }}
                px={{ base: "25px", md: "0px" }}
                mt={{ base: "40px", md: "14vh" }}
                flexDirection="column"
                style={{ marginTop: "30px" }}>

                <Box me="auto">

                    <Heading color={textColor} fontSize="36px" mb="10px">
                        Register
                    </Heading>
                </Box>

                <Box overflowY="scroll" maxH="400px">
                    {/* your content goes here */}

                    <Flex
                        zIndex="2"
                        direction="column"
                        w={{ base: "100%", md: "420px" }}
                        className='scrolling'
                        maxW="100%"
                        background="transparent"
                        borderRadius="15px"
                        mx={{ base: "auto", lg: "unset" }}
                        me="auto"
                        mb={{ base: "20px", md: "auto" }}>



                        <FormControl>

                            <>
                                {/* Name */}
                                <FormLabel
                                    display="flex"
                                    ms="4px"
                                    fontSize="sm"
                                    fontWeight="500"
                                    color={textColor}
                                    mb="8px">
                                    Name<Text color={brandStars}>*</Text>

                                </FormLabel>

                                <Input
                                    isRequired={true}
                                    variant="auth"
                                    fontSize="sm"
                                    ms={{ base: "0px", md: "0px" }}
                                    type="text"

                                    mb="24px"
                                    fontWeight="500"
                                    size="lg"
                                />
                            </>

                            <>
                                {/* Username */}
                                <FormLabel
                                    display="flex"
                                    ms="4px"
                                    fontSize="sm"
                                    fontWeight="500"
                                    color={textColor}
                                    mb="8px">
                                    UserName<Text color={brandStars}>*</Text>

                                </FormLabel>

                                <Input
                                    isRequired={true}
                                    variant="auth"
                                    fontSize="sm"
                                    ms={{ base: "0px", md: "0px" }}
                                    type="text"
                                    mb="24px"
                                    fontWeight="500"
                                    size="lg"
                                />
                            </>

                            <>
                                {/* Email */}
                                <FormLabel
                                    display="flex"
                                    ms="4px"
                                    fontSize="sm"
                                    fontWeight="500"
                                    color={textColor}
                                    mb="8px">
                                    Email<Text color={brandStars}>*</Text>

                                </FormLabel>

                                <Input
                                    isRequired={true}
                                    variant="auth"
                                    fontSize="sm"
                                    ms={{ base: "0px", md: "0px" }}
                                    type="email"
                                    mb="24px"
                                    fontWeight="500"
                                    size="lg"
                                />
                            </>

                            <>
                                {/* Password */}
                                <FormLabel
                                    ms="4px"
                                    fontSize="sm"
                                    fontWeight="500"
                                    color={textColor}
                                    display="flex">
                                    Password<Text color={brandStars}>*</Text>
                                </FormLabel>
                                <InputGroup size="md">
                                    <Input
                                        isRequired={true}
                                        fontSize="sm"
                                        placeholder="Min. 8 characters"
                                        mb="24px"
                                        size="lg"
                                        type={show ? "text" : "password"}
                                        variant="auth"
                                    />
                                    <InputRightElement display="flex" alignItems="center" mt="4px">
                                        <Icon
                                            color={textColorSecondary}
                                            _hover={{ cursor: "pointer" }}
                                            as={show ? RiEyeCloseLine : MdOutlineRemoveRedEye}
                                            onClick={handleClick}
                                        />
                                    </InputRightElement>
                                </InputGroup>

                            </>

                            <>
                                {/* Confirm password */}
                                <FormLabel
                                    ms="4px"
                                    fontSize="sm"
                                    fontWeight="500"
                                    color={textColor}
                                    display="flex">
                                    Password<Text color={brandStars}>*</Text>
                                </FormLabel>
                                <InputGroup size="md">
                                    <Input
                                        isRequired={true}
                                        fontSize="sm"
                                        placeholder="Min. 8 characters"
                                        mb="24px"
                                        size="lg"
                                        type={show ? "text" : "password"}
                                        variant="auth"
                                    />
                                    <InputRightElement display="flex" alignItems="center" mt="4px">
                                        <Icon
                                            color={textColorSecondary}
                                            _hover={{ cursor: "pointer" }}
                                            as={show ? RiEyeCloseLine : MdOutlineRemoveRedEye}
                                            onClick={handleClick}
                                        />
                                    </InputRightElement>
                                </InputGroup>


                            </>

                            <>
                                {/* Gender */}
                                <FormLabel
                                    display="flex"
                                    ms="4px"
                                    fontSize="sm"
                                    fontWeight="500"
                                    color={textColor}
                                    mb="8px">
                                    Gender<Text color={brandStars}>*</Text>

                                </FormLabel>


                                <RadioGroup defaultValue='Itachi'>
                                    <HStack spacing='24px'>
                                        <Radio value='Male'>Male</Radio>
                                        <Radio value='Female'>Female</Radio>
                                    </HStack>
                                </RadioGroup>

                            </>
                            <>

                                {/* Phone number */}
                                <FormLabel
                                    display="flex"
                                    ms="4px"
                                    fontSize="sm"
                                    fontWeight="500"
                                    color={textColor}
                                    mb="8px">
                                    Phone Number<Text color={brandStars}>*</Text>

                                </FormLabel>

                                <Input
                                    isRequired={true}
                                    variant="auth"
                                    fontSize="sm"
                                    ms={{ base: "0px", md: "0px" }}
                                    type="text"
                                    mb="24px"
                                    fontWeight="500"
                                    size="lg"
                                />

                            </>
                            <>
                                {/* DOB */}
                                <FormLabel
                                    display="flex"
                                    ms="4px"
                                    fontSize="sm"
                                    fontWeight="500"
                                    color={textColor}
                                    mb="8px">
                                    Date of birth<Text color={brandStars}>*</Text>

                                </FormLabel>

                                <Input
                                    isRequired={true}
                                    variant="auth"
                                    fontSize="sm"
                                    ms={{ base: "0px", md: "0px" }}
                                    type="date"
                                    mb="24px"
                                    fontWeight="500"
                                    size="lg"
                                />

                            </>
                            <>
                                {/* Country */}
                                <FormLabel
                                    display="flex"
                                    ms="4px"
                                    fontSize="sm"
                                    fontWeight="500"
                                    color={textColor}
                                    mb="8px">
                                    Select Country<Text color={brandStars}>*</Text>

                                </FormLabel>

                                <Input
                                    isRequired={true}
                                    variant="auth"
                                    fontSize="sm"
                                    ms={{ base: "0px", md: "0px" }}
                                    type="text"

                                    mb="24px"
                                    fontWeight="500"
                                    size="lg"
                                />

                            </>
                            <>
                                {/* State */}
                                <FormLabel
                                    display="flex"
                                    ms="4px"
                                    fontSize="sm"
                                    fontWeight="500"
                                    color={textColor}
                                    mb="8px">
                                    Select State<Text color={brandStars}>*</Text>

                                </FormLabel>

                                <Input
                                    isRequired={true}
                                    variant="auth"
                                    fontSize="sm"
                                    ms={{ base: "0px", md: "0px" }}
                                    type="text"
                                    mb="24px"
                                    fontWeight="500"
                                    size="lg"
                                />
                            </>


                            <>
                                {/* City */}
                                <FormLabel
                                    display="flex"
                                    ms="4px"
                                    fontSize="sm"
                                    fontWeight="500"
                                    color={textColor}
                                    mb="8px">
                                    Select City<Text color={brandStars}>*</Text>

                                </FormLabel>

                                <Input
                                    isRequired={true}
                                    variant="auth"
                                    fontSize="sm"
                                    ms={{ base: "0px", md: "0px" }}
                                    type="text"
                                    mb="24px"
                                    fontWeight="500"
                                    size="lg"
                                />

                            </>

                            <>
                                {/* Address */}
                                <FormLabel
                                    display="flex"
                                    ms="4px"
                                    fontSize="sm"
                                    fontWeight="500"
                                    color={textColor}
                                    mb="8px">
                                    Address<Text color={brandStars}>*</Text>

                                </FormLabel>

                                <Textarea
                                    isRequired={true}
                                    variant="auth"
                                    fontSize="sm"
                                    ms={{ base: "0px", md: "0px" }}

                                    mb="24px"
                                    fontWeight="500"
                                    size="lg"
                                />

                            </>


                            <>
                                {/* Qualification */}
                                <FormLabel
                                    display="flex"
                                    ms="4px"
                                    fontSize="sm"
                                    fontWeight="500"
                                    color={textColor}
                                    mb="8px">
                                    Qualification<Text color={brandStars}>*</Text>

                                </FormLabel>

                                <Checkbox>BCA</Checkbox>
                                <Checkbox>MCA</Checkbox>

                            </>


                            <>
                                {/* Programming skills */}
                                <FormLabel
                                    display="flex"
                                    ms="4px"
                                    fontSize="sm"
                                    fontWeight="500"
                                    color={textColor}
                                    mb="8px">
                                    Programming skills<Text color={brandStars}>*</Text>

                                </FormLabel>

                              
                                <Checkbox>Java</Checkbox>
                                <Checkbox>Python</Checkbox>

                            </>



                        </FormControl>
                        <Button fontSize="sm" variant="brand" fontWeight="500" w="100%" h="50" mb="24px" onClick={registerHandler}>Sign In</Button>
                    </Flex>
                </Box>
            </Flex >
        </DefaultAuth >

    );
}

export default Signup;