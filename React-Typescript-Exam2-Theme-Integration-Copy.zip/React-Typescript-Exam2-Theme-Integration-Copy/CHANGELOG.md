# Changelog


## [1.1.1] 2022-11-01

🚀 Feature:
-Added TimelineRow

## [1.1.0] 2022-09-21
### React Tables V8
🚀 Feature: Now Horizon UI Typescript comes in V8 version for React Tables. You can clone the repository [here](https://github.com/horizon-ui/horizon-ui-chakra-ts/tree/feature/react-table-v8) !
 
## [1.1.0] 2022-09-21
### React Tables V8
🚀 Feature: Now Horizon UI Typescript comes in V8 version for React Tables. You can clone the repository [here](https://github.com/horizon-ui/horizon-ui-chakra-ts/tree/feature/react-table-v8) !

## [1.0.1] 2022-09-7
### Bug Fixing 
Mapbox bug when using `yarn` fixed.

## [1.0.0] 2022-08-31
### Official Release 
- Added TypeScript!
