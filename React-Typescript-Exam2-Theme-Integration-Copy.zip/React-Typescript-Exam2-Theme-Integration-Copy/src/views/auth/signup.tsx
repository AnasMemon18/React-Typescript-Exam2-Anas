import DefaultAuth from "layouts/auth/Default";
import illustration from "assets/img/auth/auth.png";
import routes from "routes";
import React, { ChangeEvent, FormEvent, useState, useEffect } from "react";
import { NavLink, useHistory } from "react-router-dom";

import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { MdOutlineRemoveRedEye } from "react-icons/md";
import { RiEyeCloseLine } from "react-icons/ri";
// Chakra imports
import {
  Box,
  Button,
  Checkbox,
  Flex,
  FormControl,
  FormLabel,
  Heading,
  HStack,
  HTMLChakraComponents,
  Icon,
  Input,
  InputGroup,
  InputRightElement,
  Radio,
  RadioGroup,
  Select,
  Text,
  Textarea,
  useColorModeValue,
} from "@chakra-ui/react";
// Custom components

function Signup() {
  // Use states!
  const [country, setCountry] = useState("");
  const [state, setState] = useState(""); // state based on the country!

  const [qualificationList, setQualificationList] = useState<String[]>([]);
  const [skillsList, setSkillsList] = useState<String[]>([]);

  const [isValid, setIsValid] = useState(false);
  const [formState, setFormState] = useState({
    password: "",
  });
  const [errorMsg, setErrorMsg] = useState("");

  // Chakra color mode
  const textColor = useColorModeValue("navy.700", "white");
  const textColorSecondary = "gray.400";
  const textColorDetails = useColorModeValue("navy.700", "secondaryGray.600");
  const textColorBrand = useColorModeValue("brand.500", "white");
  const brandStars = useColorModeValue("brand.500", "brand.400");

  // Regex patterns
  var textPattern = /^[A-Za-z]+$/;
  var usernamePattern = /^[A-Za-z]+[0-9]*$/;
  var emailPattern = /^[a-z0-9]+@[a-z]+[.][a-z]+$/;
  var phonePattern = /^[0-9]{10}$/;
  var dt = new Date();

  const history = useHistory();

  const [show, setShow] = React.useState(false);
  const handleClick = () => setShow(!show);

  useEffect(() => {
    // console.log(formState);
    // console.log(qualificationList);
    // console.log(skillsList);
  }, [formState, country, skillsList, qualificationList]);

  // Main register handler
  const registerHandler = (event: React.FormEvent) => {
    event.preventDefault();
    if (isValid) {
      const data = {
        data: JSON.stringify(formState),
        qualification: JSON.stringify(qualificationList),
        skills: JSON.stringify(skillsList),
      };
      console.log("Data: ", data);
      fetch("http://localhost:5000/registerUser", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      })
        .then((response) => {
          return response.json();
        })
        .then((data) => {
          console.log("Data: ", data);
          if (data.status == "201") {
            toast.success("User registered successfully!", {
              position: toast.POSITION.TOP_RIGHT,
            });
            setTimeout(() => {
              history.push("/");
            }, 3000);
          }
        })
        .catch((error) => console.error(error));
    } else {
      toast.error("Kindly check the inputs !", {
        position: toast.POSITION.TOP_RIGHT,
      });
    }
  };

  //Main changeHandler
  const changeHandler = (event: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = event.target;

    if (name == "name") {
      if (value.match(textPattern)) {
        setIsValid(true);
        setFormState((prevData) => ({
          ...prevData,
          [name]: value,
        }));
        setErrorMsg("");
        console.log(formState);
      } else {
        setIsValid(false);
        setErrorMsg("Invalid FirstName! (Enter characters only)");
      }
    }

    if (name == "username") {
      if (value.match(usernamePattern)) {
        setIsValid(true);
        setFormState((prevData) => ({
          ...prevData,
          [name]: value,
        }));
        setErrorMsg("");
      } else {
        setIsValid(false);
        setErrorMsg("Invalid UserName! (Enter characters and numbers only)");
      }
    }

    if (name == "email") {
      if (value.match(emailPattern)) {
        setIsValid(true);
        setFormState((prevData) => ({
          ...prevData,
          [name]: value,
        }));
        setErrorMsg("");
      } else {
        setIsValid(false);
        setErrorMsg("Invalid Email!");
      }
    }

    if (name == "password") {
      if (value.length >= 6) {
        setIsValid(true);
        setFormState((prevData) => ({
          ...prevData,
          [name]: value,
        }));
        setErrorMsg("");
      } else {
        setIsValid(false);
        setErrorMsg("Password must be atleast 6 characters");
      }
    }

    if (name == "confirmPassword") {
      if (formState.password == value) {
        setIsValid(true);
        setFormState((prevData) => ({
          ...prevData,
          [name]: value,
        }));
        setErrorMsg("");
      } else {
        setIsValid(false);
        setErrorMsg("Passwords should match!");
      }
    }

    if (name == "phoneNumber") {
      if (value.match(phonePattern)) {
        setIsValid(true);
        setFormState((prevData) => ({
          ...prevData,
          [name]: value,
        }));
        setErrorMsg("");
      } else {
        setIsValid(false);
        setErrorMsg("Invalid PhoneNumber! (Enter numbers only)");
      }
    }

    if (name == "dob") {
      var currentYear = dt.getFullYear();
      var year = Number(value.substring(0, 4));

      if (currentYear - year < 18) {
        setIsValid(false);
        setErrorMsg("You must be adult!");
      } else {
        setIsValid(true);
        setFormState((prevData) => ({
          ...prevData,
          [name]: value,
        }));
        setErrorMsg("");
      }
    }

    if (name == "file") {
      console.log("INSIDE");
      if (event.target.files[0].size <= 1000000) {
        console.log("ok");
        setIsValid(true);
        setFormState((prevData) => ({
          ...prevData,
          [name]: event.target.files[0].name,
        }));
        setErrorMsg("");
      } else {
        setIsValid(false);
        setErrorMsg("File is too big");
      }
    }
  };

  //CountryDropDownHandler handler
  const countryDropDownHandler = (
    event: React.ChangeEvent<HTMLSelectElement>
  ) => {
    setFormState((prevData) => ({
      ...prevData,
      [event.target.name]: event.target.value,
    }));
    setIsValid(true);
    setCountry(event.target.value);
  };

  //StateDropDownHandler handler
  const stateDropDownHandler = (
    event: React.ChangeEvent<HTMLSelectElement>
  ) => {
    setFormState((prevData) => ({
      ...prevData,
      [event.target.name]: event.target.value,
    }));
    setIsValid(true);
    setState(event.target.value);
  };

  const addressHandler = (event: React.ChangeEvent<HTMLTextAreaElement>) => {
    setFormState((prevData) => ({
      ...prevData,
      [event.target.name]: event.target.value,
    }));
    setIsValid(true);
  };

  // Checkbox handler
  const checkboxHandler = (event: React.ChangeEvent<HTMLInputElement>) => {
    const value = event.target.value;
    const isChecked = event.target.checked;

    if (event.target.name == "qualification") {
      if (isChecked) {
        setQualificationList([...qualificationList, value]);
      } else {
        let index = qualificationList.indexOf(value);
        qualificationList.splice(index, 1);
      }
    } else if (event.target.name == "skills") {
      if (isChecked) {
        setSkillsList([...skillsList, value]);
      } else {
        let index = skillsList.indexOf(value);
        skillsList.splice(index, 1);
      }
    }
  };

  // Gender handler
  const genderHandler = (event: React.ChangeEvent<HTMLInputElement>) => {
    setFormState((prevData) => ({
      ...prevData,
      [event.target.name]: event.target.value,
    }));
  };

  // JSX Code
  return (
    <React.Fragment>
      <DefaultAuth illustrationBackground={illustration} image={illustration}>
        <Flex
          maxW={{ base: "100%", md: "max-content" }}
          w="100%"
          mx={{ base: "auto", lg: "0px" }}
          me="auto"
          alignItems="start"
          justifyContent="center"
          mb={{ base: "30px", md: "60px" }}
          px={{ base: "25px", md: "0px" }}
          mt={{ base: "40px", md: "14vh" }}
          flexDirection="column"
          style={{ marginTop: "30px" }}
        >
          <Flex flexDirection="row">
            <Box me="auto">
              <Heading color={textColor} fontSize="36px" mb="10px">
                Register
              </Heading>
            </Box>

            <Box me="auto" style={{ marginLeft: "205px" }}>
              <NavLink to={`/`}>
                <Text color={textColorDetails} fontWeight="400" fontSize="14px">
                  Already a user ?
                </Text>

                <Text
                  style={{ marginLeft: "30px" }}
                  color={textColorBrand}
                  as="span"
                  ms="5px"
                  fontWeight="500"
                >
                  Login
                </Text>
              </NavLink>
            </Box>
          </Flex>
          <ToastContainer />

          {/* Main form BOX */}
          <span style={{ color: "red" }}>{errorMsg}</span>
          <Box overflowY="scroll" maxH="400px">
            <Flex
              zIndex="2"
              direction="column"
              w={{ base: "100%", md: "420px" }}
              className="scrolling"
              maxW="100%"
              background="transparent"
              borderRadius="15px"
              mx={{ base: "auto", lg: "unset" }}
              me="auto"
              mb={{ base: "20px", md: "auto" }}
            >
              <FormControl>
                {/* Name */}
                <>
                  <FormLabel
                    display="flex"
                    ms="4px"
                    fontSize="sm"
                    fontWeight="500"
                    color={textColor}
                    mb="8px"
                  >
                    Name<Text color={brandStars}>*</Text>
                  </FormLabel>
                  <Input
                    isRequired={true}
                    variant="auth"
                    fontSize="sm"
                    ms={{ base: "0px", md: "0px" }}
                    type="text"
                    mb="24px"
                    fontWeight="500"
                    size="lg"
                    onChange={changeHandler}
                    name="name"
                  />
                </>

                {/* Username */}
                <>
                  <FormLabel
                    display="flex"
                    ms="4px"
                    fontSize="sm"
                    fontWeight="500"
                    color={textColor}
                    mb="8px"
                  >
                    UserName<Text color={brandStars}>*</Text>
                  </FormLabel>

                  <Input
                    isRequired={true}
                    variant="auth"
                    fontSize="sm"
                    ms={{ base: "0px", md: "0px" }}
                    type="text"
                    mb="24px"
                    fontWeight="500"
                    size="lg"
                    name="username"
                    onChange={changeHandler}
                  />
                </>

                {/* Email */}
                <>
                  <FormLabel
                    display="flex"
                    ms="4px"
                    fontSize="sm"
                    fontWeight="500"
                    color={textColor}
                    mb="8px"
                  >
                    Email<Text color={brandStars}>*</Text>
                  </FormLabel>
                  <Input
                    isRequired={true}
                    variant="auth"
                    fontSize="sm"
                    ms={{ base: "0px", md: "0px" }}
                    type="email"
                    mb="24px"
                    fontWeight="500"
                    size="lg"
                    name="email"
                    onChange={changeHandler}
                  />
                </>

                {/* Password */}
                <>
                  <FormLabel
                    ms="4px"
                    fontSize="sm"
                    fontWeight="500"
                    color={textColor}
                    display="flex"
                  >
                    Password<Text color={brandStars}>*</Text>
                  </FormLabel>
                  <InputGroup size="md">
                    <Input
                      isRequired={true}
                      fontSize="sm"
                      placeholder="Min. 6 characters"
                      mb="24px"
                      size="lg"
                      type={show ? "text" : "password"}
                      variant="auth"
                      name="password"
                      onChange={changeHandler}
                    />
                    <InputRightElement
                      display="flex"
                      alignItems="center"
                      mt="4px"
                    >
                      <Icon
                        color={textColorSecondary}
                        _hover={{ cursor: "pointer" }}
                        as={show ? RiEyeCloseLine : MdOutlineRemoveRedEye}
                        onClick={handleClick}
                      />
                    </InputRightElement>
                  </InputGroup>
                </>

                {/* Confirm password */}
                <>
                  <FormLabel
                    ms="4px"
                    fontSize="sm"
                    fontWeight="500"
                    color={textColor}
                    display="flex"
                  >
                    Confirm Password<Text color={brandStars}>*</Text>
                  </FormLabel>
                  <InputGroup size="md">
                    <Input
                      isRequired={true}
                      fontSize="sm"
                      placeholder="Min. 6 characters"
                      mb="24px"
                      size="lg"
                      type={show ? "text" : "password"}
                      variant="auth"
                      name="confirmPassword"
                      onChange={changeHandler}
                    />
                    <InputRightElement
                      display="flex"
                      alignItems="center"
                      mt="4px"
                    >
                      <Icon
                        color={textColorSecondary}
                        _hover={{ cursor: "pointer" }}
                        as={show ? RiEyeCloseLine : MdOutlineRemoveRedEye}
                        onClick={handleClick}
                      />
                    </InputRightElement>
                  </InputGroup>
                </>

                {/* Phone number */}
                <>
                  <FormLabel
                    display="flex"
                    ms="4px"
                    fontSize="sm"
                    fontWeight="500"
                    color={textColor}
                    mb="8px"
                  >
                    Phone Number<Text color={brandStars}>*</Text>
                  </FormLabel>
                  <Input
                    isRequired={true}
                    variant="auth"
                    fontSize="sm"
                    ms={{ base: "0px", md: "0px" }}
                    type="text"
                    mb="24px"
                    fontWeight="500"
                    size="lg"
                    name="phoneNumber"
                    onChange={changeHandler}
                  />
                </>

                {/* Gender */}
                <>
                  <FormLabel
                    display="flex"
                    ms="4px"
                    fontSize="sm"
                    fontWeight="500"
                    color={textColor}
                    mb="8px"
                  >
                    Gender<Text color={brandStars}>*</Text>
                  </FormLabel>
                  <Text color={brandStars}>
                    {" "}
                    <input
                      onChange={genderHandler}
                      type="radio"
                      name="gender"
                      value="male"
                      style={{ marginRight: "10px" }}
                    />
                    Male
                  </Text>
                  <Text color={brandStars}>
                    {" "}
                    <input
                      onChange={genderHandler}
                      type="radio"
                      name="gender"
                      value="female"
                      style={{ marginRight: "10px" }}
                    />
                    Female
                  </Text>
                </>

                {/* DOB */}
                <>
                  <FormLabel
                    display="flex"
                    ms="4px"
                    fontSize="sm"
                    fontWeight="500"
                    color={textColor}
                    mb="8px"
                    style={{ marginTop: "20px" }}
                  >
                    Date of birth<Text color={brandStars}>*</Text>
                  </FormLabel>
                  <Input
                    isRequired={true}
                    variant="auth"
                    fontSize="sm"
                    ms={{ base: "0px", md: "0px" }}
                    type="date"
                    mb="24px"
                    fontWeight="500"
                    size="lg"
                    onChange={changeHandler}
                    name="dob"
                  />
                </>

                {/* Country */}
                <>
                  <FormLabel
                    display="flex"
                    ms="4px"
                    fontSize="sm"
                    fontWeight="500"
                    color={textColor}
                    mb="8px"
                  >
                    Select Country<Text color={brandStars}>*</Text>
                  </FormLabel>
                  <select
                    style={{ backgroundColor: "#4318ff" }}
                    name="country"
                    onChange={countryDropDownHandler}
                  >
                    <option value="">--Select Country--</option>
                    <option value="india">India</option>
                    <option value="australia">Australia</option>
                  </select>
                </>

                {/* State */}
                <>
                  <FormLabel
                    display="flex"
                    ms="4px"
                    fontSize="sm"
                    fontWeight="500"
                    color={textColor}
                    mb="8px"
                    style={{ marginTop: "20px" }}
                  >
                    Select State<Text color={brandStars}>*</Text>
                  </FormLabel>
                  <select
                    style={{ backgroundColor: "#4318ff" }}
                    name="state"
                    onChange={stateDropDownHandler}
                    disabled={country ? false : true}
                  >
                    {country == "india" && (
                      <>
                        <option value="">--Select State--</option>
                        <option value="gujarat">Gujarat</option>
                        <option value="goa">Goa</option>
                      </>
                    )}

                    {country == "australia" && (
                      <>
                        <option value="">--Select State--</option>
                        <option value="queensland">Queensland</option>
                        <option value="victoria">Victoria</option>
                      </>
                    )}
                  </select>
                </>

                {/* City */}
                <>
                  <FormLabel
                    display="flex"
                    ms="4px"
                    fontSize="sm"
                    fontWeight="500"
                    color={textColor}
                    mb="8px"
                    style={{ marginTop: "20px" }}
                  >
                    Select City<Text color={brandStars}>*</Text>
                  </FormLabel>
                  <select
                    style={{ backgroundColor: "#4318ff" }}
                    name="city"
                    onChange={countryDropDownHandler}
                    disabled={state ? false : true}
                  >
                    {state == "gujarat" && (
                      <>
                        <option value="">--Select City--</option>
                        <option value="ahmedabad">Ahmedabad</option>
                        <option value="baroda">Baroda</option>
                        <option value="surat">Surat</option>
                      </>
                    )}
                    {state == "goa" && (
                      <>
                        <option value="">--Select City--</option>
                        <option value="panji">Panji</option>
                        <option value="margao">Margao</option>
                        <option value="quepam">Quepam</option>
                      </>
                    )}
                    {state == "queensland" && (
                      <>
                        <option value="">--Select City--</option>
                        <option value="brisbane">Brisbane</option>
                        <option value="cairns">Cairns</option>
                        <option value="rockhampton">Rockhampton</option>
                      </>
                    )}
                    {state == "victoria" && (
                      <>
                        <option value="">--Select City--</option>
                        <option value="melbourne">Melbourne</option>
                        <option value="warrnambool">Warrnambool</option>
                        <option value="mildura">Mildura</option>
                      </>
                    )}
                  </select>
                </>

                {/* Address */}
                <>
                  <FormLabel
                    display="flex"
                    ms="4px"
                    fontSize="sm"
                    fontWeight="500"
                    color={textColor}
                    mb="8px"
                    style={{ marginTop: "20px" }}
                  >
                    Address<Text color={brandStars}>*</Text>
                  </FormLabel>

                  <Textarea
                    isRequired={true}
                    variant="auth"
                    fontSize="sm"
                    ms={{ base: "0px", md: "0px" }}
                    mb="24px"
                    fontWeight="500"
                    size="lg"
                    onChange={addressHandler}
                    name="address"
                  />
                </>

                {/* Qualification */}
                <>
                  <FormLabel
                    display="flex"
                    ms="4px"
                    fontSize="sm"
                    fontWeight="500"
                    color={textColor}
                    mb="8px"
                    style={{ marginTop: "20px" }}
                  >
                    Qualification<Text color={brandStars}>*</Text>
                  </FormLabel>
                  <b>
                    <Text color={brandStars}>
                      {" "}
                      <input
                        onChange={checkboxHandler}
                        type="checkbox"
                        name="qualification"
                        value="bca"
                      />
                      BCA
                    </Text>

                    <Text color={brandStars}>
                      {" "}
                      <input
                        onChange={checkboxHandler}
                        type="checkbox"
                        name="qualification"
                        value="mca"
                      />
                      MCA
                    </Text>
                  </b>
                </>

                {/* Programming skills */}
                <>
                  <FormLabel
                    display="flex"
                    ms="4px"
                    fontSize="sm"
                    fontWeight="500"
                    color={textColor}
                    mb="8px"
                    style={{ marginTop: "20px" }}
                  >
                    Programming skills<Text color={brandStars}>*</Text>
                  </FormLabel>

                  <b>
                    <Text color={brandStars}>
                      {" "}
                      <input
                        type="checkbox"
                        name="skills"
                        onChange={checkboxHandler}
                        value="java"
                      />
                      Java
                    </Text>

                    <Text color={brandStars}>
                      {" "}
                      <input
                        type="checkbox"
                        name="skills"
                        onChange={checkboxHandler}
                        value="python"
                      />
                      Python
                    </Text>
                  </b>
                </>
              </FormControl>

              {/* File upload */}
              <>
                <FormLabel
                  display="flex"
                  ms="4px"
                  fontSize="sm"
                  fontWeight="500"
                  color={textColor}
                  mb="8px"
                  style={{ marginTop: "20px" }}
                >
                  Profile<Text color={brandStars}>*</Text>
                  <input
                    type="file"
                    name="file"
                    id="file"
                    onChange={changeHandler}
                    accept="/*"
                    style={{ color: "white" }}
                  />
                </FormLabel>
              </>

              <Button
                fontSize="sm"
                variant="brand"
                fontWeight="500"
                w="100%"
                h="50"
                mb="24px"
                onClick={registerHandler}
              >
                Sign Up
              </Button>
            </Flex>
          </Box>
        </Flex>
      </DefaultAuth>
    </React.Fragment>
  );
}

export default Signup;
