import { DeleteIcon, EditIcon, WarningIcon } from "@chakra-ui/icons";
import {
  Avatar,
  Box,
  Button,
  Flex,
  Progress,
  Table,
  Tbody,
  Icon,
  Td,
  Text,
  Thead,
  Tr,
  useColorModeValue,
  Th,
} from "@chakra-ui/react";
import {
  createColumnHelper,
  flexRender,
  getCoreRowModel,
  getSortedRowModel,
  SortingState,
  useReactTable,
} from "@tanstack/react-table";
// Custom components
import * as React from "react";
// Assets

import { useHistory } from "react-router-dom";

type RowObj = {
  srno: number;
  name: string;
  email: string;
  phonenumber: string;
  action: any;
};

const columnHelper = createColumnHelper<RowObj>();

// const columns = columnsDataCheck;
export default function TopCreatorTable(props: any) {
  const [users, setUsers] = React.useState([]);
  const getRoleId = localStorage.getItem('roleId');
  console.log("This is roleID :", getRoleId);
  var getUsers: any;
  React.useEffect(() => {
    fetch("http://localhost:5000/getUsers")
      .then((response) => response.json())
      .then((data) => {
        getUsers = data;
        setUsers(data);
        console.log("Users: ", users);
      })
      .catch((error) => {
        console.error(error);
      });
  }, []);

  console.log("Users: ", typeof users);
  const { tableData } = props;
  console.log(props);

  const [sorting, setSorting] = React.useState<SortingState>([]);
  const textColor = useColorModeValue("secondaryGray.900", "white");
  const textColorSecondary = useColorModeValue("secondaryGray.600", "white");
  const borderColor = useColorModeValue("gray.200", "whiteAlpha.100");
  let defaultData = tableData;

  const columns = [
    columnHelper.accessor("srno", {
      id: "srno",
      header: () => (
        <Text
          justifyContent="space-between"
          align="center"
          fontSize={{ sm: "10px", lg: "12px" }}
          color="gray.400"
        >
          Sr No
        </Text>
      ),
      cell: (info: any) => (
        <Flex align="center">
          <Text color={textColor} fontSize="sm" fontWeight="600">
            1{/* {info.getValue()[0]} */}
          </Text>
        </Flex>
      ),
    }),
    columnHelper.accessor("name", {
      id: "name",
      header: () => (
        <Text
          justifyContent="space-between"
          align="center"
          fontSize={{ sm: "10px", lg: "12px" }}
          color="gray.400"
        >
          Name
        </Text>
      ),
      cell: (info) => (
        <Text color={textColorSecondary} fontSize="sm" fontWeight="500">
          k{/* {info.getValue()} */}
        </Text>
      ),
    }),
    columnHelper.accessor("email", {
      id: "email",
      header: () => (
        <Text
          justifyContent="space-between"
          align="center"
          fontSize={{ sm: "10px", lg: "12px" }}
          color="gray.400"
        >
          Email
        </Text>
      ),
      cell: (info) => (
        <Text color={textColorSecondary} fontSize="sm" fontWeight="500">
          Email
          {/* {info.getValue()} */}
        </Text>
      ),
    }),
    columnHelper.accessor("phonenumber", {
      id: "phonenumber",
      header: () => (
        <Text
          justifyContent="space-between"
          align="center"
          fontSize={{ sm: "10px", lg: "12px" }}
          color="gray.400"
        >
          Phone Number
        </Text>
      ),
      cell: (info) => (
        <Text color={textColorSecondary} fontSize="sm" fontWeight="500">
          12345
          {/* {info.getValue()} */}
        </Text>
      ),
    }),
    columnHelper.accessor("action", {
      id: "action",
      header: () => (
        <Text
          justifyContent="space-between"
          align="center"
          fontSize={{ sm: "10px", lg: "12px" }}
          color="gray.400"
        >
          Action
        </Text>
      ),
      cell: (info) => (
        <>
          <Button colorScheme="blue" style={{ margin: "0 10px 0 10px" }}>
            {" "}
            <Icon as={EditIcon} />
          </Button>
          <Button colorScheme="red">
            <Icon as={DeleteIcon} />
          </Button>
        </>
      ),
    }),
  ];

  const [data, setData] = React.useState(() => [...defaultData]);
  const table = useReactTable({
    data,
    columns,
    state: {
      sorting,
    },
    onSortingChange: setSorting,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    debugTable: true,
  });
  const history = useHistory();

  const gotoAddProduct = (event: React.FormEvent) => {
    event.preventDefault();
    // history.push('/admin/addproduct');
  };

  return (
    <Flex
      direction="column"
      w="100%"
      overflowX={{ sm: "scroll", lg: "hidden" }}
    >
      <Flex
        align={{ sm: "flex-start", lg: "center" }}
        justify="space-between"
        w="100%"
        px="22px"
        pb="20px"
        mb="10px"
        boxShadow="0px 40px 58px -20px rgba(112, 144, 176, 0.26)"
      >
        <Text color={textColor} fontSize="xl" fontWeight="600">
          Users List
        </Text>
        <Button variant="action" onClick={gotoAddProduct}>
          + Add
        </Button>
      </Flex>
      <Box>
        <Table variant="simple" color="gray.500" mt="12px">
          <Tr>
            <Th>Sr No.</Th>
            <Th>Name</Th>
            <Th>Email</Th>
            <Th>Phone</Th>
            {getRoleId=="1" && <Th>Action</Th>}
          </Tr>
          <Tbody>
            {users.map((user, index) => (
              <Tr key={index}>
                <Td
                  fontSize={{ sm: "14px" }}
                  minW={{ sm: "150px", md: "200px", lg: "auto" }}
                  borderColor="transparent"
                >
                  {index + 1}
                </Td>
                <Td
                  fontSize={{ sm: "14px" }}
                  minW={{ sm: "150px", md: "200px", lg: "auto" }}
                  borderColor="transparent"
                >
                  {user.name}
                </Td>
                <Td
                  fontSize={{ sm: "14px" }}
                  minW={{ sm: "150px", md: "200px", lg: "auto" }}
                  borderColor="transparent"
                >
                  {user.email}
                </Td>
                <Td
                  fontSize={{ sm: "14px" }}
                  minW={{ sm: "150px", md: "200px", lg: "auto" }}
                  borderColor="transparent"
                >
                  {user.phoneNumber}
                </Td>
                <Td>
				{getRoleId=='1' &&  <><Button
							colorScheme="blue"
							style={{ margin: "0 10px 0 10px" }}
						>
							<Icon as={EditIcon} />
						</Button><Button colorScheme="red">
								<Icon as={DeleteIcon} />
							</Button></>}	
                 
                </Td>
              </Tr>
            ))}
          </Tbody>
        </Table>
      </Box>
    </Flex>
  );
}
