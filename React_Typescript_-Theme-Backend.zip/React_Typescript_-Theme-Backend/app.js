const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
const cookieParser = require("cookie-parser");
const router = require("./routes/router");
const app = express();
app.use(cookieParser());

const cors = require("cors");

app.use(cors());

app.use(bodyParser.json());

mongoose.connect(
  `mongodb+srv://root:root@cluster0.jzewljl.mongodb.net/react_typescript?retryWrites=true&w=majority
    `,
  {
  }
);
const db = mongoose.connection;
db.on("error", console.error.bind(console, "connection error: "));
db.once("open", function () {
  console.log("Connected successfully");
});

app.use(router);

app.listen(5000, () => console.log("Server started on port 5000."));
