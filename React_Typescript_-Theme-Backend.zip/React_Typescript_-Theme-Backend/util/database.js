// const Sequelize = require("sequelize");

// const sequelize = new Sequelize(
//     'expensereact',
//     'anas',
//     'password', 
//     {
//         Server: 'localhost',
//         dialect : 'postgres'
//     }
// );


// sequelize.authenticate().then(()=>{console.log("")}).catch(err=>{
//         console.log(err)
//     })
    
// module.exports = sequelize;
   
