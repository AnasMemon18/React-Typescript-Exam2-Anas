const User = require("../models/user");

const addExpense = async (req, res, next) => {
  const data = JSON.parse(req.body.data);
  const qualifications = JSON.parse(req.body.qualification);
  const skills = JSON.parse(req.body.skills);

  const user = new User({
    name: data.name,
    username: data.username,
    email: data.email,
    password: data.password,
    phoneNumber: data.phoneNumber,
    gender: data.gender,
    dateOfBirth: data.dob,
    country: data.country,
    state: data.state,
    city: data.city,
    address: data.address,
    qualifications: qualifications.toString(),
    skills: skills.toString(),
    image: data.file,
  });

  try {
    await user.save();
    res.status(201).send({ msg: "User registered successfully!", status: "201" });
  } catch (error) {
    res.status(500).send(error);
  }
};

const login = async (req, res, next) => {
  const {email, password} = req.body;
  try {
    const user = await User.findOne({ email: email }).maxTimeMS(20000).exec();
    if(user){
      if(user.password == password){
        if(user.roleId == 1){
          res.cookie("RoleId", 1);
        }
        else{
          res.cookie("RoleId", 0);
        }
        return res.status(200).json({status: '200', msg: "Logged in successfully!", roleId:user.roleId})
      }else{k
        return res.status(404).json({status: '404', error: "Password incorrect!" });
      }
    }else{
      return res.status(404).json({status: '404', error: "User not found!" });
    }
  } catch (err) {
    console.error(err);
  }
};

const getUsers = (req, res, next) => {
  User.find({ roleId: { $ne: 1 } })
  .then(users => {
    res.send(users);
  })
  .catch(error => {
    console.error(error);
  });
};

module.exports = { addExpense, login, getUsers };
