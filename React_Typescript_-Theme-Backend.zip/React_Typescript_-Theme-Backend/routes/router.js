const express = require("express");

const expenseController = require('../controller/expenseController');

const router = express.Router();

router.post('/registerUser', expenseController.addExpense);
router.post('/login', expenseController.login);


router.get('/getUsers', expenseController.getUsers);

module.exports = router